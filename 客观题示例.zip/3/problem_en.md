# 1.  Completion

1+1 = {{ input(1) }}

# 2.  choice question

{{ select(2) }}
- 1+1=2
- 1+1=3
- 1+1=4

# 3.  Multiple Choice Questions

## answer is A B
{{ multiselect(3) }}
- A
- B
- C
