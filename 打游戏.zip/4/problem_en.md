# Description

Xiaoming is playing a game, and it is known that he can earn $n$ experience points by completing it every minute. If he completes it, he will need $m$ experience points. So please help him calculate how long it will take for Xiaoming to clear the level at least?
# Format
## Input
There is a line of input with 2 positive integers $n$ and $m$.

## Output
The output only has one integer, indicating how many minutes it takes for Xiaoming to clear the level.

```input1
500 1005
```
```output1
3
```
```input2
3 10
```
```output2
4
```
```input3
1020 1321145
```
```output3
1296
```
# Hint
## Data Range
For 50% of the data

$1＜n＜m≤10^9$  

For 100% of the data

$0≤n＜m≤2147483647$

## Source:

[luogu U454293](https://www.luogu.com.cn/problem/U454293)
