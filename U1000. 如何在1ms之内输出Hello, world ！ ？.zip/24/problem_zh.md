# 题目背景
如何在1ms之内输出Hello, world! ？

~~不是我怎么出了这样一道题啊~~

# 题目描述
输出 Hello, world!

# 格式

## 输入格式
本题没有输入。

## 输出格式
输出有一行，有一个字符串：`Hello, world!`

在**1ms**内完成。

# 样例

```input1
（无）
```

```output1
Hello, world!
```
# 提示
## 限制
1ms
## 来源
[洛谷U473047](https://www.luogu.com.cn/problem/U473047)
