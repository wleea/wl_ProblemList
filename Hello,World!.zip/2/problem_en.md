# Description
This is a beginning

Output Hello, World!

 
# Format

## Input

No input.

## Output

Output 'Hello, World!'

# Samples

```input1
(None)
```

```output1
Hello,World!
```